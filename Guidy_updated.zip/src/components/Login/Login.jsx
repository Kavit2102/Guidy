import React from 'react'
import './Login.css';

import MainLogo from '../MainLogo/MainLogo';
import LoginForm from './LoginForm/LoginForm';

const Login = () => {
  return (
      <div className='Login'>
        <MainLogo/>
        <LoginForm/>
      </div>
  )
}

export default Login