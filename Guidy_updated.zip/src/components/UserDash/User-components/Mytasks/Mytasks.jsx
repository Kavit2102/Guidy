import React from 'react'
import './Mytasks.css'

import TaskItem from '../TaskItem/TaskItem'
import styles from './Mytasks.module.css';

const Mytasks = ({tasks,deleteTask, toggleTask, enterEditMode }) => {  

  return (    
    <div className='mytsk'>
      <span>My Tasks</span>
      <div className="taskList">
      <ul className={styles.tasks}>
      {
        tasks.sort((a,b)=>b.id-a.id).map(task =>(
          <TaskItem
            key={task.id}
            task={task}
            deleteTask={deleteTask}
            toggleTask={toggleTask}
            enterEditMode={enterEditMode}
          />
        ))
      }
      </ul>
      </div>
    </div>
  )
}

export default Mytasks

        