import React from 'react'
import './Calenderbox.css'

const Calender = () => {
  return (
    <div className='clndr'>
      <span>Calender</span>
    </div>
  )
}

export default Calender